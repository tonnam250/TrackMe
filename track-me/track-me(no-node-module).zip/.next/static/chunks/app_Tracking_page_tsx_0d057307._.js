(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/app_tracking_page_tsx_ff8717d6._.js"
],
    source: "dynamic"
});
