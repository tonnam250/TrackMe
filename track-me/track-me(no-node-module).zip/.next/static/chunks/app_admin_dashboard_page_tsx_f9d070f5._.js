(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_993d405d._.js",
  "static/chunks/node_modules_46868040._.js",
  "static/chunks/app_admin_dashboard_page_tsx_08a05697._.js"
],
    source: "dynamic"
});
